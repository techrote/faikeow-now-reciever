#!/usr/bin/env python3
"""Verify payload hashes, base path collisions, and patch/overlay equivalence offline."""
from pathlib import Path
import hashlib,json,subprocess,tempfile
root=Path(__file__).resolve().parent
rows=(root/'SHA256SUMS').read_text().splitlines();expected={}
for line in rows:
    digest,name=line.split('  ',1)
    p=root/name
    if not p.resolve().is_relative_to(root) or not p.is_file(): raise SystemExit('Invalid member '+name)
    if hashlib.sha256(p.read_bytes()).hexdigest()!=digest: raise SystemExit('Hash mismatch '+name)
    expected[name]=digest
actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and p.name!='SHA256SUMS'}
if actual!=set(expected): raise SystemExit('Unlisted/missing payload files: '+str(actual^set(expected)))
overlay=root/'proposed';files=[p for p in overlay.rglob('*') if p.is_file()]
base=set(json.loads((root/'evidence/assessment.json').read_text())['base_files'])
if base&{p.relative_to(overlay).as_posix() for p in files}: raise SystemExit('Patch collides with assessed existing file')
with tempfile.TemporaryDirectory() as td:
    subprocess.run(['git','init','-q',td],check=True,timeout=10)
    subprocess.run(['git','-C',td,'apply','--check',str(root/'proposed.patch')],check=True,timeout=10)
    subprocess.run(['git','-C',td,'apply',str(root/'proposed.patch')],check=True,timeout=10)
    for p in files:
        if (Path(td)/p.relative_to(overlay)).read_bytes()!=p.read_bytes(): raise SystemExit('Patch differs from overlay')
print(json.dumps({'payload_files_sha256_verified':len(expected),'patch_files_verified':len(files),'base_path_collisions':0,'patch_application_scope':'empty scratch Git tree plus assessed base-path collision check; NOT full assessed Git object checkout','status':'PASS'},indent=2))
