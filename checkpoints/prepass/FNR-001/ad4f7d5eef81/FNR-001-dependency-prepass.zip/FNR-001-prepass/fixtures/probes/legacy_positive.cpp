#include <stdint.h>
#include <type_traits>
typedef uint8_t u8; // SDK c_types prelude only, not a replacement header.
#include "espnow.h"
static_assert(std::is_same<esp_now_recv_cb_t, void(*)(uint8_t*,uint8_t*,uint8_t)>::value, "legacy ABI");
static_assert(std::is_same<decltype(&esp_now_add_peer),int(*)(u8*,u8,u8,u8*,u8)>::value, "legacy peer ABI");
void on_rx(u8*,u8*,u8) {}
esp_now_recv_cb_t callback = on_rx;
