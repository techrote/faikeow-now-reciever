#include <stdint.h>
typedef uint8_t u8;
#include "espnow.h"
void on_rx(const uint8_t*, const uint8_t*, int) {}
esp_now_recv_cb_t callback = on_rx; // MUST be rejected, never cast to silence it.
