#include <stdint.h>
typedef uint8_t u8;
#include "espnow.h"
struct esp_now_recv_info; // A foreign API's metadata object, deliberately not defined.
void on_rx(const esp_now_recv_info*, const uint8_t*, int) {}
esp_now_recv_cb_t callback = on_rx; // MUST be rejected.
