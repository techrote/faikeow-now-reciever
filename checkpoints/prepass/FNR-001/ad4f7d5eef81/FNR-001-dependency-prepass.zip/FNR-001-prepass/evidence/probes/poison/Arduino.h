#error SDK leakage into shared code
