# Retrieval and execution limits
The GitHub read connector and web reader provided source text/metadata.
The first shell clone failed with `Could not resolve host: github.com`.
Container downloads of archive/checksum resources failed. Arm's checksum URL was
reported as unsupported `application/octet-stream` by the web reader and failed
through container.download. No compiler/SDK binary archives were installed.
The two retained target-preflight logs are actual executions. Earlier tool retrieval
failures are summarized here rather than presented as fabricated shell transcript files.
