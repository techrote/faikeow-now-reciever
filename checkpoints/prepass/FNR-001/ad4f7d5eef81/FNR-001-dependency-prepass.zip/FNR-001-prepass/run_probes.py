#!/usr/bin/env python3
"""Offline finite prepass probes. All builds stay under caller-selected output dir."""
from pathlib import Path
import argparse, hashlib, json, os, platform, shutil, subprocess, sys, time
p=argparse.ArgumentParser();p.add_argument('--out',default='results');a=p.parse_args()
root=Path(__file__).resolve().parent; out=Path(a.out).resolve();out.mkdir(parents=True,exist_ok=True)
rows=[]
def run(name,cmd,expect=0):
    start=time.monotonic()
    try:
        r=subprocess.run(cmd,cwd=root,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=45)
        rc=r.returncode; text=r.stdout
    except (OSError,subprocess.TimeoutExpired) as e:
        rc=124;text=str(e)
    ok=(rc==expect) if expect==0 else (rc!=0 and rc!=124)
    (out/(name+'.log')).write_text('$ '+ ' '.join(map(str,cmd))+'\n'+text+'\nreturncode='+str(rc)+'\n')
    row={'name':name,'command':list(map(str,cmd)),'returncode':rc,'expected':'zero' if expect==0 else 'compiler rejection','passed':ok,'elapsed_seconds':round(time.monotonic()-start,3)}
    rows.append(row); print(name, 'PASS' if ok else 'FAIL', flush=True);return ok
O=root/'proposed'; b=out/'build-native'; inc=str(O/'shared/include')
run('environment',['sh','-c','uname -a; gcc --version; g++ --version; clang --version; cmake --version; ninja --version; python3 --version; make --version; perl -e \'print "$^V\\n"\'; command -v arm-none-eabi-gcc || true; command -v xtensa-lx106-elf-gcc || true'])
run('native_configure',['cmake','-S',str(O),'-B',str(b),'-G','Ninja','-DCMAKE_BUILD_TYPE=Debug','-DCMAKE_C_FLAGS=-fsanitize=undefined -fno-sanitize-recover=all','-DCMAKE_CXX_FLAGS=-fsanitize=undefined -fno-sanitize-recover=all'])
run('native_build',['cmake','--build',str(b),'--parallel','2'])
run('native_ctest',['ctest','--test-dir',str(b),'--output-on-failure'])
run('native_trace',[str(b/'fnr_native_tests')])
poison=out/'poison'
for h in ['Arduino.h','espnow.h','esp_now.h','tusb.h','pico/stdlib.h','freertos/FreeRTOS.h']:
    f=poison/h;f.parent.mkdir(parents=True,exist_ok=True);f.write_text('#error SDK leakage into shared code\n')
run('sdk_independent_c',['gcc','-std=c17','-Wall','-Wextra','-Werror','-I'+str(poison),'-I'+inc,'-c',str(O/'shared/src/datagram.c'),'-o',str(out/'shared-host.o')])
run('arm_freestanding_headers',['clang','--target=arm-none-eabi','-mcpu=cortex-m0plus','-mthumb','-ffreestanding','-std=c17','-Wall','-Wextra','-Werror','-I'+str(poison),'-I'+inc,'-c',str(O/'tests/native/arm_layout.c'),'-o',str(out/'arm-layout.o')])
run('arm_freestanding_shared',['clang','--target=arm-none-eabi','-mcpu=cortex-m0plus','-mthumb','-ffreestanding','-std=c17','-Wall','-Wextra','-Werror','-I'+inc,'-c',str(O/'shared/src/datagram.c'),'-o',str(out/'arm-shared.o')])
run('arm_object_identity',['readelf','-h',str(out/'arm-layout.o')])
for n in ['legacy_positive','rtos_negative','esp32_negative']:
    run(n,['g++','-std=c++17','-Wall','-Wextra','-Werror','-I'+str(root/'fixtures/upstream'),'-c',str(root/'fixtures/probes'/f'{n}.cpp'),'-o',str(out/f'{n}.o')],expect=0 if n=='legacy_positive' else 1)
# Verify exact upstream header, not merely a callback mock.
f=root/'fixtures/upstream/espnow.h';data=f.read_bytes();bid=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
expected='2e1c2dbf6b35b629459910542045ee32da00c420'
rows.append({'name':'upstream_header_git_blob','passed':bid==expected,'actual':bid,'expected':expected})
results={'scope':'host and compile-only probes; NOT complete SDK cross-builds, RF or USB tests','python':sys.version,'platform':platform.platform(),'checks':rows,'all_passed':all(x['passed'] for x in rows),'unexecuted':['RP2040 SDK+TinyUSB complete ELF/UF2 link','ESP8266 core+SDK complete ELF/BIN link','RF/USB/hardware tests','two independent clean firmware rebuilds']}
(out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
sys.exit(0 if results['all_passed'] else 1)
