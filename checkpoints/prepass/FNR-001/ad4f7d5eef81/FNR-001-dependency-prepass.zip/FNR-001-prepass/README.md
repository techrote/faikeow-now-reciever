# FNR-001 packet
Start with HANDOFF.md, then FINDINGS.md. Source identities are in SOURCES.json and
proposed/dependencies.lock.json. The proposed/ directory is an additive repo overlay;
proposed.patch is generated from exactly those files. Evidence and fixtures stay outside
active firmware paths. Run `python3 run_probes.py --out /tmp/fnr-prepass-results` offline.
Verify the packet with `python3 verify_packet.py` and the external ZIP SHA256SUMS file.
The ZIP is a verified packet, NOT verified complete firmware or an accepted FNR-001 implementation.
